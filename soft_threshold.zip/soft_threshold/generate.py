import numpy as np




class generate_data:
    def __init__(self, sigma,dim):
        
        self.sigma= sigma
        self.dim= dim
    
    def function(self,X):
        #return (1+ 2*np.linalg.norm(X, axis=1)/np.sqrt(self.dim))**3
        return X[:,0] +X[:,1]
        #return 3*np.sin( np.sum(X, axis=1))
        #return np.linalg.norm(X, axis=1)**2
        #return np.sum(np.sin(2*np.pi*X),axis=1)
    def generate_training(self, N ):
        #X=  np.random.randn(N, self.dim)
        X = np.random.rand(N, self.dim)

        epsilon = self.sigma*np.random.randn(N)
        y =  self.function(X) + epsilon
         
        return y, X
    
    def generate_test(self, N):
        #X=np.random.randn(N, self.dim)
        X =  np.random.rand(N, self.dim)

        #y_true=3*np.sin(np.sum(X, axis=1))
        y_true=  self.function(X)
        return y_true, X
    
    



class generate_linear:
    def __init__(self, sigma,dim):
        
        self.sigma= sigma
        self.dim= dim
        
    def generate_training(self, N ):
        X=  np.random.randn(N, self.dim)
        epsilon = self.sigma*np.random.randn(N)
        y = np.sum(X, axis=1) + epsilon
        return y, X
    
    def generate_test(self, N):
        X=np.random.randn(N, self.dim)
        y_true= np.sum(X, axis=1)
        return y_true, X


"""
import matplotlib.pyplot as plt

plt.figure() 
plt.hist(y_true, bins=30, edgecolor='black')  # try 30 bins (adjust as desired)
plt.xlabel('y value')
plt.ylabel('Frequency')
plt.title('Histogram of y')
plt.tight_layout()
plt.show()

"""