import numpy as np
from sklearn.linear_model import LinearRegression


class linear_model:
    def __init__(self, y_train, X_train):
        self.model = LinearRegression()
        self.model.fit(X_train, y_train)
        
    
    def predict(self, X_test):
        y_pred = self.model.predict(X_test)
        return y_pred
    
    
#########################
#########################


import tensorflow as tf
#tf.keras.backend.clear_session()
from tensorflow.keras import Sequential, Input
from tensorflow.keras.layers import Dense


class NN_model:
    def __init__(self, y_train, X_train, hidden_layers, 
                 epochs=100, batch_size=32, verbose=0):
        tf.keras.backend.clear_session()
        input_dim = X_train.shape[1]
        
        self.model = Sequential()
        self.model.add(Input(shape=(input_dim,)))
        for units in hidden_layers:
            self.model.add(Dense(units, activation='relu'))
        self.model.add(Dense(1, activation='linear'))
        self.model.compile(optimizer='adam', loss='mse')
        self.model.fit(X_train, y_train,
                       epochs=epochs,
                       batch_size=batch_size,
                       verbose=verbose)
    
    def predict(self, X_test):
        return self.model.predict(X_test).ravel()


###################
####################



from sklearn.kernel_ridge import KernelRidge

class ridge_model:
    def __init__(self, y_train, X_train,
                 alpha=1.0,
                 #kernel='rbf',
                 kernel='poly',
                 gamma=None,
                 degree=5,
                 coef0=1.0,
                 **kwargs):
        """
        Wraps sklearn.kernel_ridge.KernelRidge with the same interface as your linear_model.

        Parameters
        ----------
        y_train : array-like, shape (n_samples,)
            Training targets.
        X_train : array-like, shape (n_samples, n_features)
            Training data.
        alpha : float, default=1.0
            Regularization strength.
        kernel : str or callable, default='rbf'
            Kernel type to be used in the algorithm.
        gamma : float, default=None
            Kernel coefficient for 'rbf', 'poly' and 'sigmoid'.
        degree : int, default=3
            Degree for poly kernels. Ignored by other kernels.
        coef0 : float, default=1.0
            Independent term in poly and sigmoid kernels.
        **kwargs : additional keyword arguments passed to KernelRidge
        """
        self.model = KernelRidge(
            alpha=alpha,
            kernel=kernel,
            gamma=gamma,
            degree=degree,
            coef0=coef0,
            **kwargs
        )
        self.model.fit(X_train, y_train)

    def predict(self, X_test):
        
        return self.model.predict(X_test)


