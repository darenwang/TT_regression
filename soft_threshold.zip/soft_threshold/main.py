


from competitors import linear_model, NN_model,ridge_model
import numpy as np
from generate import generate_data

N_train=5000
dim=10
sigma=0.00001
N_test=10000



generator=generate_data(sigma, dim)
y_train, X_train = generator.generate_training(N_train)

y_true, X_test = generator.generate_test(N_test)



#######TT soft Nystrom


from polynomial_optimized import generate_basis_mat
from TT_utility import    TT_prediction
from TT_iteration import cores_initialization, TT_iterate

#

n=3

ranks=[2 for __ in range(dim)]
s=200

mu=0.5/ dim 


alpha=1/np.sqrt(dim*n)/10
#alpha=1
basis_generator =generate_basis_mat(n, dim,alpha)
basis_mat= basis_generator.all_x_multivariate(X_train)  
basis_mat = basis_mat.transpose(1, 0, 2)
x_inverse_mat=basis_generator.all_x_multivariate_inverse_alpha(X_train)


######O(N^2) vanilla  initialization cores
cur_core_set = cores_initialization( N_train,dim,n ,ranks ,basis_mat, y_train).all_cores()

mat_test= basis_generator.all_x_multivariate_inverse_alpha(X_test)

y_TT_full = TT_prediction().predict(dim,cur_core_set, mat_test)
print(np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true))

######end of initialization


iterations =1000


for rr in range(iterations):
    
    cur_core_set= TT_iterate(N_train,n, dim ,ranks ,basis_mat, x_inverse_mat, cur_core_set, y_train,mu).all_cores()
    if rr% 10==0:
        print('iteration=',rr)

        
        y_TT_full= TT_prediction().predict(dim, cur_core_set, mat_test)



        mse_gradient= np.linalg.norm(y_TT_full-y_true)/np.linalg.norm( y_true)
        print(mse_gradient)




#soft initialization + soft iterate

from nystrom import cores_initialization, TT_iterate


cur_core_set = cores_initialization( N_train,dim,n ,ranks,s,basis_mat, y_train).all_cores()

mat_test= basis_generator.all_x_multivariate_inverse_alpha(X_test)

y_TT_full = TT_prediction().predict(dim,cur_core_set, mat_test)
print(np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true))

######end of initialization


iterations =1000


for rr in range(iterations):
    
    cur_core_set= TT_iterate(N_train,n, dim ,ranks,s,basis_mat, x_inverse_mat, cur_core_set, y_train,mu).all_cores()
    if rr% 10==0:
        print('iteration=',rr)

        
        y_TT_full= TT_prediction().predict(dim, cur_core_set, mat_test)



        mse_gradient= np.linalg.norm(y_TT_full-y_true)/np.linalg.norm( y_true)
        print(mse_gradient)







#####
lr= linear_model(y_train, X_train)
y_pred= lr.predict(X_test)

mse= np.linalg.norm(y_pred-y_true)/np.linalg.norm( y_true)
print('Linear',mse)




NN = NN_model (y_train, X_train, [30,30,30])
y_NN=NN.predict(X_test)
mse= np.linalg.norm(y_NN-y_true)/np.linalg.norm( y_true)
print('NN',mse)



############
"""
kernel_ridge= ridge_model(y_train, X_train)
y_kernel= kernel_ridge.predict(X_test)
mse= np.linalg.norm(y_kernel-y_true)/np.linalg.norm(y_true)
print(mse)
"""
