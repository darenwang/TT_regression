import numpy as np


class form_nystrom_matrix:
    def __init__(self,dim,N,n,s):
        self.dim=dim
        self.N = N
        self.n = n
        self.s =s 
    def compute(self, basis_mat):
        dp_M= [[] for __ in range(self.dim)]
        dp_W= [[] for __ in range(self.dim)]
        I_index =  np.random.choice(self.N, size=self.s, replace=False)
        temp= basis_mat[self.dim-1][I_index,:] 
        dp_M[self.dim-1] = basis_mat[self.dim-1] @ temp.T
        dp_W[self.dim-1]= temp@temp.T
        
        for j in range(self.dim-2,0,-1):
            temp= basis_mat[j][I_index,:] 
            
            dp_M[j]= dp_M[j+1]* (basis_mat[j] @ temp.T)
            dp_W[j]= dp_W[j+1] * (temp@temp.T)
        return dp_M, dp_W





class cores_initialization:
    def __init__(self, N,dim,n ,ranks,s,basis_mat, y_train) -> None:
        self.N=N
        self.dim=dim
        self.n=n
        #ranks are size dim vector and ranks[j] is the rank of the j-th coordinate
        self.ranks=ranks

        self.core_set=[]
        #self.core_set[j] is the j-th core of size (rank[j-1], n, rank[j]) 
        ## basis_mat[i][j][k] corresponds to  phi_k(X_i(j)). 
        #i is the label of data 
        #j is the coordinate of data
        #k is label of basis
        #I do not like np.copy here. It is costly
        #However, I want to make sure basis_mat is not touched in this function
        self.basis_xy =  basis_mat.transpose(1, 0, 2).copy()
        
        self.basis_xy[0, :, :] = self.basis_xy[0, :, :] * y_train[:, None]

        self.dp_M, self.dp_W = form_nystrom_matrix(dim, N, n,s).compute(self.basis_xy)
        self.basis_xy=list(self.basis_xy)

    def all_cores(self):
         
        
        for j in range(0,self.dim-1):
            #compute the symmetric targeted matrix
            
            target_mat= self.basis_xy[j].T @ self.dp_M[j+1] @  np.linalg.pinv( self.dp_W [j+1], rcond=1e-8) @self.dp_M[j+1].T @self.basis_xy[j]
            
            
            G_cur=np.linalg.svd(target_mat , full_matrices=False, hermitian=True)[0][:,:self.ranks[j]]
            
             
            
            if j==0:
                G_cur_tensor= G_cur
            if j>0:
                #G_cur is shape (ranks[j-1]*n ,ranks[j])
                G_cur_tensor =G_cur.reshape(self.ranks[j-1],self.n,self.ranks[j])
            self.core_set.append(G_cur_tensor)
            #self.core_set[j] is shape (ranks[j-1],n, ranks[j ])
            
            
            
            #print(self.basis_mat[0][j].shape)
            #i=0
            #print(np.tensordot(G_cur,self.basis_mat[0][j],axes=(0,0)))
            #print(np.outer( np.tensordot(G_cur,self.basis_mat[i][j],axes=(0,0)), self.basis_mat[i][j+1] ).reshape(-1))
            #G_cur is shape ( ranks[j-1]*n ,rank[j] )
            #self.basis_xy[i][j ] is shape (N, ranks[j-1]*n )
            #the updated version of self.basis_xy[j+1] is  shape (N, ranks[j]*n)
            
            A_temp =  self.basis_xy[j] @ G_cur
            B_temp = self.basis_xy[j+1]
            
            self.basis_xy[j+1] = (A_temp[:, :, None] * B_temp[:, None, :]).reshape(self.N, -1)
        
        #print(self.ranks)
        ###last core
        G_temp =self.basis_xy[self.dim-1].sum(axis=0) 
        self.core_set.append(G_temp.reshape(self.ranks[self.dim-2],self.n) /self.N  )

        return self.core_set 


#####################






from TT_utility import TT_prediction


class core_squares:
    def __init__(self):
        pass
    def compute(self,core_set, dim):
        #square_set is a list of size dim 
        #square_set[j] is shape (r,r)
        #and equals to G_j (G_{j+1}...G_d ) (G_{j+1}...G_d) ^T G_j^top
        square_set=[[] for __ in range(dim)]
        
        square_set[dim-1] = core_set[dim-1]@ core_set[dim-1].T
        for j in range(dim-2, 0,-1):
            square_set[j]= np.einsum('abc, ce, dbe -> ad', core_set[j], square_set[j+1], core_set[j])
           
        square_set[0] =   np.einsum('ab, bc, dc -> ad', core_set[0], square_set[1], core_set[0])
        return square_set
    
    
    
class cores_times_rank_one:
    def __init__(self):
        pass
    def compute(self, core_set, basis_mat,dim):
        #cross_term_set is a list of size dim 
        #cross_term_set[j] is shape (r,1)
        cross_term_dp=[[] for __ in range(dim)]
        #rec is (r,N)
        #basis_mat is a list here 
        keep = np.einsum('rn,Nn->rN', core_set[dim-1],  basis_mat[dim-1]) 
        
        cross_term_dp[dim-1] = keep
        for j in range(dim-2, 0,-1): 
            temp = np.einsum('ilk,pl->ikp', core_set[j],  basis_mat[j]) 
            #temp is shape (r,r,N)
            #keep is shape (r,N)
            keep= np.einsum('irN,rN->iN', temp, keep)
            
            cross_term_dp[j]=  keep
        #cross_term_set[0]=   
        return cross_term_dp
#cross_term_dp [j] is (r, N), with j=1,..., dim-1

#dp_mat = form_dp_matrix(dim, N_train, n).compute(basis_mat)
    
    


class TT_iterate:
    def __init__(self,N_train,n, dim ,ranks,s,basis_mat, x_inverse_mat, core_set, y_train,mu):
        self.N=N_train
        self.dim=dim
        self.n=n
        self.ranks=ranks
        self.old_core=core_set
        #for m in range(dim):
        #    self.old_core[m]=np.zeros(self.old_core[m].shape )
        
        
        self.new_core=[]
        ######
        self.square_set = core_squares().compute(self.old_core, dim)
        y_t = TT_prediction().predict(dim, self.old_core, x_inverse_mat)
        self.y_t=y_t
        new_y= mu * (y_train - y_t)
        self.basis_xy =  np.copy ( basis_mat ) 
        #self.basis_xy= np.zeros((dim, N_train, n))
        self.basis_xy[0, :, :] = self.basis_xy[0, :, :] * new_y[:, None]
        self.basis_xy = list( self.basis_xy)
        self.dp_M, self.dp_W = form_nystrom_matrix(dim, N_train, n,s).compute(self.basis_xy)
        self.cross_term_dp = cores_times_rank_one().compute(self.old_core, self.basis_xy,dim)
    def first_core(self):
        
        ####A_1 is the square of the TT_t, where TT_t is shape (n, n^{dim-1})
        A_1 = self.square_set[0]
        ####A_3 is the square of the rank N sum of rank 1 tensors (y_train[i] -y_t[i])Phi (X[i])
        A_3=self.basis_xy[0].T @ self.dp_M[ 1] @  np.linalg.pinv( self.dp_W [ 1], rcond=1e-8) @self.dp_M[ 1].T  @self.basis_xy[0]/(self.N**2)
        #####A_2 is the cross term of the square. Here m =n
        A_2= np.einsum(' nr, rN, Nm-> nm', self.old_core[0], self.cross_term_dp[1], self.basis_xy[0] )
        A_2= (A_2+A_2.T)/self.N
        
        #compute the target matrix
        target_mat = A_1+A_2+A_3
        
        ####compute first core
        G_cur=np.linalg.svd(target_mat , full_matrices=False, hermitian=True)[0][:,:self.ranks[0]]
        self.new_core.append(G_cur)
        
        ####update basis_xy
        #G_cur is shape ( n, ranks[0]  )
        #the updated version of self.basis_xy[1] is shape (N,ranks[0]*n)
        
        A_temp =  self.basis_xy[0] @ G_cur
        #self.basis_xy[0] is shape(N,n). G_cur is shape (n,r)
        #A_temp is shape (N,r). self.basis_xy[1] is shape( N,n)
        #It is probability the best to keep self.basis_xy[1] of shape (N,r,n) to avoid any confusions
        self.basis_xy[1]=np.einsum('Nr, Nn -> Nrn', A_temp, self.basis_xy[1]).reshape(self.N, -1)

        #####update self.core_set, self.core_set[1] is (r_0, n,r_1)
        self.old_core[1]= np.einsum('nr, na,amb -> rmb', self.new_core[0], self.old_core[0], self.old_core[1]).reshape(self.ranks[0]*self.n, -1)
        
        return self.new_core[0]

    def all_cores(self):
        self.first_core()
        
        for j in range(1,self.dim-1):
            #print(j)
            ####A_1 is the square of the GTT_t,  where GTT_t (rn, n^{j-2})
            A_1 = self.old_core[j]@self.square_set[j+1] @self.old_core[j].T
            ####A_3 is the square of the rank N sum of rank 1 tensors G Phi (X[i])(y_train[i] -y_t[i])
            A_3 =self.basis_xy[j].T @ self.dp_M[j+1] @  np.linalg.pinv( self.dp_W [j+1], rcond=1e-8) @self.dp_M[j+1].T  @self.basis_xy[j]/(self.N**2)
            #####A_2 is the cross term of the square
            A_2= np.einsum('ar, rN, Nm->am', self.old_core[j], self.cross_term_dp[j+1], self.basis_xy[j] )
            A_2= (A_2+A_2.T)/self.N
            target_mat= A_1+A_2+A_3
            
            G_cur=np.linalg.svd(target_mat , full_matrices=False, hermitian=True)[0][:,:self.ranks[j]]
            
            
            
            
            G_cur_tensor =G_cur.reshape(self.ranks[j-1],self.n,self.ranks[j])
            self.new_core.append(G_cur_tensor)
            #self.core_set[j] is shape (ranks[j-1],n, ranks[j ])
            
            #G_cur is shape ( ranks[j-1]*n ,rank[j] )
            #self.basis_xy[j] is shape (N, ranks[j-1]*n )
            #A_temp is shape (N, ranks[j])
            A_temp =  self.basis_xy[j] @ G_cur
            #self.basis_xy[j+1] is shape (N, n)
            
            #self.basis_xy[j+1] is shape (N, n*ranks[j])
            self.basis_xy[j+1]=np.einsum('Nr, Nn -> Nrn', A_temp, self.basis_xy[j+1]).reshape(self.N, -1)
            #self.basis_xy[1] = (A_temp[:, :, None] * B_temp[:, None, :]).reshape(self.N, -1)
            
            
            temp=self.new_core[j].reshape(self.ranks[j-1]*self.n, -1)
            #print(j, temp.shape, self.core_set[j].shape,self.core_set[j+1].shape )
            #return np.einsum('ab, ac,cmd -> bmd', temp, self.core_set[j], self.core_set[j+1]).reshape(self.ranks[j]*self.n, -1)
            if j!= self.dim-2:
            #####update self.core_set, self.core_set[j+1] is (r_{j} n,r_{j+1})
                self.old_core[j+1]= np.einsum('ab, ac,cmd -> bmd', temp, self.old_core[j], self.old_core[j+1]).reshape(self.ranks[j]*self.n, -1)
            else:
                self.old_core[j+1]= np.einsum('ab, ac,cm -> bm', temp, self.old_core[j], self.old_core[j+1])

            
            
        
        ###last core
        G_temp =self.basis_xy[self.dim-1].sum(axis=0) 
        self.new_core.append(G_temp.reshape(self.ranks[self.dim-2],self.n) /self.N +self.old_core[self.dim-1] )

        return self.new_core