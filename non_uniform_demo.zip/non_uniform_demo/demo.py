


from competitors import linear_model, NN_model,ridge_model
import numpy as np
from generate import generate_data

N_train=3000
dim=20
sigma=0
N_test=10000

#generator=generate_data(sigma, dim)
#y_train, X_train = generator.generate_training(N_train)

#y_true, X_test = generator.generate_test(N_test)



from cg import solve_cg
from polynomial import generate_basis_mat

from TT_utility import  TT_prediction

from nystrom_non_uniform import cores_initialization, TT_iterate
for rr in range(100):


    generator=generate_data(sigma, dim)
    y_train, X_train = generator.generate_training(N_train)

    y_true, X_test = generator.generate_test(N_test)

    
    n=5
    alpha=1/np.sqrt(dim*n)/10
    aa = solve_cg(X_train, y_train,n, dim, N_train,alpha).lstsq()

    

    s=200

    ranks=[4 for __ in range(dim)]
    ranks[0]=min(ranks[0],n)


    basis_mat  = generate_basis_mat(n, dim,alpha, X_train).compute()

    ######initialization cores

    init_core_set  = cores_initialization( N_train,dim,n ,ranks,s,basis_mat , aa).all_cores()
    
    mat_test= generate_basis_mat(n, dim,alpha, X_test).compute()  

    y_TT = TT_prediction().predict(dim,init_core_set, mat_test)
    print('rr',rr)
    print( 'TT',  np.linalg.norm(y_TT  -y_true)/np.linalg.norm( y_true)) 

    lr = linear_model(y_train, X_train)
    y_pred = lr.predict(X_test)

    mse= np.linalg.norm(y_pred-y_true)/np.linalg.norm( y_true)
    print('Linear',mse)




    NN = NN_model (y_train, X_train, [40,40,40])
    y_NN=NN.predict(X_test)
    mse= np.linalg.norm(y_NN-y_true)/np.linalg.norm( y_true)
    print('NN',mse)

    










""" 





############################ 
############################ 
############################ 
############################ cg with weight**2
from cg import solve_cg
n=3
alpha=1/np.sqrt(dim*n)/10
aa = solve_cg(X_train, y_train,n, dim, N_train,alpha).lstsq()
#np.savez('initialization.npz', aa=aa, X_train=X_train, y_train=y_train, X_test=X_test, y_true=y_true) 

from polynomial import generate_basis_mat

from TT_utility import  TT_prediction

from nystrom_non_uniform import cores_initialization, TT_iterate

s=200

ranks=[4 for __ in range(dim)]
ranks[0]=min(ranks[0],n)

basis_mat  = generate_basis_mat(n, dim,alpha, X_train).compute()

######initialization cores

#np.load('initialization.npz')
init_core_set  = cores_initialization( N_train,dim,n ,ranks,s,basis_mat , aa).all_cores()
cg_core_set= [init_core_set[kk].copy() for kk in range(dim) ]
mat_test= generate_basis_mat(n, dim,alpha, X_test).compute()  

y_TT = TT_prediction().predict(dim,cg_core_set, mat_test)
print(np.linalg.norm(y_TT  -y_true)/np.linalg.norm( y_true)) 

########iterate

def unweight(weight, core_set):
    inverse_vec=np.ones(n)*weight
    inverse_vec[0]=1
    core_set[0]= np.einsum('Nr, N->Nr', core_set[0], inverse_vec)
    for dd in range(1, dim-1):
        core_set[dd]=np.einsum('sNr, N->sNr',  core_set[dd], inverse_vec)

    core_set[-1]= np.einsum('rN, N->rN',  core_set[-1], inverse_vec)




#####
#####
#####
#####no weights
iterations =1000
iteration_mat=generate_basis_mat(n, dim,alpha**-1, X_train).compute()
predict_train_mat =generate_basis_mat(n, dim,alpha , X_train).compute()  
mat_test= generate_basis_mat(n, dim,alpha, X_test).compute()

mu=0.1
for rr in range(iterations):
    
    cg_core_set= TT_iterate(N_train,n, dim ,ranks,s,iteration_mat, predict_train_mat , cg_core_set, y_train,mu).all_cores()
    if rr% 10==0:
        print('iteration=',rr)

        
        y_TT_full= TT_prediction().predict(dim, cg_core_set, mat_test)



        mse_gradient= np.linalg.norm(y_TT_full-y_true)/np.linalg.norm( y_true)
        print(mse_gradient)
        if mse_gradient>2:
            break
        
        

#####
#####
#####
#####  weight ^1
cg_core_set= [init_core_set[kk].copy() for kk in range(dim) ]
unweight(alpha, cg_core_set)
iterations =1000
iteration_mat=generate_basis_mat(n, dim,1, X_train).compute()
predict_train_mat =generate_basis_mat(n, dim,1 , X_train).compute()  
mat_test= generate_basis_mat(n, dim,1, X_test).compute()

mu=0.1
for rr in range(iterations):
    
    cg_core_set= TT_iterate(N_train,n, dim ,ranks,s,iteration_mat, predict_train_mat , cg_core_set, y_train,mu).all_cores()
    if rr% 10==0:
        print('iteration=',rr)

        
        y_TT_full= TT_prediction().predict(dim, cg_core_set, mat_test)



        mse_gradient= np.linalg.norm(y_TT_full-y_true)/np.linalg.norm( y_true)
        print(mse_gradient)
        if mse_gradient>2:
            break



#####
#####
#####
#####  weight^2 
cg_core_set= [init_core_set[kk].copy() for kk in range(dim) ]
unweight(alpha**2, cg_core_set)
iterations =1000
iteration_mat=generate_basis_mat(n, dim,alpha, X_train).compute()
predict_train_mat =generate_basis_mat(n, dim,alpha**-1 , X_train).compute()  
mat_test= generate_basis_mat(n, dim,alpha**-1, X_test).compute()

mu=0.1
for rr in range(iterations):
    
    cg_core_set= TT_iterate(N_train,n, dim ,ranks,s,iteration_mat, predict_train_mat , cg_core_set, y_train,mu).all_cores()
    if rr% np.round(10/np.sqrt(dim))==0:
        print('iteration=',rr)

        
        y_TT_full= TT_prediction().predict(dim, cg_core_set, mat_test)



        mse_gradient= np.linalg.norm(y_TT_full-y_true)/np.linalg.norm( y_true)
        print(mse_gradient)
        if mse_gradient>2:
            break


#0.004238950744193737
#iteration= 39
#0.004200624255560773
#iteration= 40
#0.007459205743985655
#iteration= 41
#1.2244261320714158e+19

 


############################ 
############################ 
############################ other ways

from TT_utility import    TT_prediction

from nystrom import cores_initialization, TT_iterate

n=4

ranks=[2 for __ in range(dim)]
s=200
#ranks=[i+2 for i in range(dim)]

mu=0.1
#mu=0.1


alpha=1/np.sqrt(dim*n)/10
#alpha=1
basis_mat= generate_basis_mat(n, dim,alpha, X_train).compute()
  
######initialization cores
cur_core_set = cores_initialization( N_train,dim,n ,ranks,s,basis_mat, y_train).all_cores()
mat_test= generate_basis_mat(n, dim,alpha**-1, X_train).compute()

y_TT_full = TT_prediction().predict(dim,cur_core_set, mat_test)
print(np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true))

######end of initialization
predict_train_mat = generate_basis_mat(n, dim,alpha**-1, X_train).compute()

iterations =400


for rr in range(iterations):
    
    cur_core_set= TT_iterate(N_train,n, dim ,ranks,s,basis_mat, predict_train_mat, cur_core_set, y_train,mu).all_cores()
    if rr% 10==0:
        print('iteration=',rr)

        
        y_TT_full= TT_prediction().predict(dim, cur_core_set, mat_test)
        mse_gradient= np.linalg.norm(y_TT_full-y_true)/np.linalg.norm( y_true)
        print(mse_gradient)



#####
lr = linear_model(y_train, X_train)
y_pred = lr.predict(X_test)

mse= np.linalg.norm(y_pred-y_true)/np.linalg.norm( y_true)
print('Linear',mse)




NN = NN_model (y_train, X_train, [60,60,60])
y_NN=NN.predict(X_test)
mse= np.linalg.norm(y_NN-y_true)/np.linalg.norm( y_true)
print('NN',mse)

"""

############
"""
kernel_ridge= ridge_model(y_train, X_train)
y_kernel= kernel_ridge.predict(X_test)
mse= np.linalg.norm(y_kernel-y_true)/np.linalg.norm(y_true)
print(mse)
"""




""" 

#####################
#####################
##################### exp cost
from polynomial import generate_basis_mat

basis_mat =generate_basis_mat(n, dim,1,X_train).compute()



acc = basis_mat[:, 0, :]                  # shape (N, n)
for k in range(1, dim):
    # acc is (N, n**k), basis_mat[:,k,:] is (N, n)
    # broadcast multiply to get shape (N, n**k, n),
    # then flatten to (N, n**(k+1))
    acc = (acc[:, :, None] * basis_mat[:, k, None, :]).reshape( N_train, -1)

#acc is  ( N, n^d)  
b=np.einsum('N, Np->p',y_train, acc)
AA=acc.T@acc
#np.linalg.norm(AA/N_train -np.diag([1 for __ in range(n**dim)]))


xx=np.linalg.lstsq(AA, b, rcond=None)[0]
#np.linalg.norm(AA@xx-b)
full_tensor= xx.reshape(tuple([n for __ in range(dim)]))


from TT_utility import full_tensor_TT, TT_prediction
alpha=1/np.sqrt(dim*n)/10


soft_weight=np.array([alpha for __ in range(n)])
soft_weight[0]=1
for dd in range(dim):
    idx = (None,)*dd + (slice(None),) + (None,)*(dim - dd - 1)
    full_tensor= full_tensor*soft_weight[idx]
    

full_core_set= full_tensor_TT().compute_svd( dim, n, ranks, full_tensor)





######initialization cores
mat_test= generate_basis_mat(n, dim,alpha**-1,X_test).compute()  

y_TT_full = TT_prediction().predict(dim,full_core_set, mat_test)
print(np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true))

"""

