import numpy as np
from scipy.sparse.linalg import cg, LinearOperator

from polynomial import generate_basis_mat


def cg_jacobi_dense(A, b,N_train, lam=None, rtol=1e-8, atol=0.0, maxiter=None, x0=None):
    """
    Solve (A + lam*I) x = b with Conjugate Gradient using a Jacobi (diagonal) preconditioner.
    A : (n,n) dense numpy array (assumed symmetric up to FP noise)
    b : (n,) dense numpy array
    """
    A = np.asarray(A, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64).reshape(-1)
    n = A.shape[0]
    if maxiter is None:
        maxiter = 10 * n

    # 1) Symmetrize (cheap & stabilizes CG)
    A = 0.5 * (A + A.T)

    # 2) Tiny diagonal jitter (makes PSD → PD)
    if lam is None:
        s = np.linalg.norm(A, ord=np.inf)
        lam = 10**-5* (s if np.isfinite(s) and s > 0 else 1.0)
        #lam= 
    Areg = A.copy()
    Areg.flat[::n+1] += lam

    # 3) Jacobi preconditioner M^{-1} = diag(Areg)^{-1}
    D = np.diag(Areg).copy()
    D[np.abs(D) < 1e-7] = 1.0
    Minv = 1.0 / D
    M = LinearOperator((n, n), matvec=lambda v: Minv * v, dtype=np.float64)

    # 4) CG solve on (A + lam I)
    x, info = cg(Areg, b, M=M, rtol=rtol, atol=atol, maxiter=maxiter, x0=x0)
    return x, info



class solve_cg:
    def __init__(self, X_train, y_train,n, dim, N_train,alpha):
        self.basis_mat=generate_basis_mat(n, dim, alpha,X_train).compute()
        self.y_train=y_train
        self.dim=dim
        self.N_train=N_train
        self.G_mat=self.compute_G_mat()
        #print(self.G_mat)
        #self.G_mat_square= self.G_mat@self.G_mat

    def compute_G_mat(self):
        # basis_mat shape: (N, dim, n); for each d, form K^(d) = B_d @ B_d^T and Hadamard-multiply
        B = self.basis_mat
        N, D, _ = B.shape
        G = np.ones((self.N_train, self.N_train), dtype=float)
        for dd in range(self.dim):
            Bd = B[:, dd, :]             # (N, n)
            G *= Bd @ Bd.T              # accumulate Hadamard product
        return G 
    
    
    def compute(self):
        vv, info = cg_jacobi_dense(self.G_mat, self.y_train, self.N_train)   
        print(info)
        return vv
    
    def lstsq(self): 
        return np.linalg.lstsq(self.G_mat, self.y_train, rcond=10**-8)[0]