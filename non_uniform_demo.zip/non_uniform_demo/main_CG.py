


from competitors import linear_model, NN_model,ridge_model
import numpy as np
from generate import generate_data

N_train=5000
dim=5
sigma=1
N_test=10000



generator=generate_data(sigma, dim)
y_train, X_train = generator.generate_training(N_train)

y_true, X_test = generator.generate_test(N_test)



####### 

from polynomial_optimized import generate_basis_mat
n=2
basis_mat =generate_basis_mat(n, dim,1).all_x_multivariate(X_train)  




class CG_tensor:
    def __init__(self, X_train, y_train,n, dim, N_train):
        self.basis_mat=generate_basis_mat(n, dim,1).all_x_multivariate(X_train)  
        self.y_train=y_train
        self.dim=dim
        self.N_train=N_train
        self.G_mat=self.compute_G_mat()
        #print(self.G_mat)
        #self.G_mat_square= self.G_mat@self.G_mat

    def compute_G_mat(self):
        # basis_mat shape: (N, dim, n); for each d, form K^(d) = B_d @ B_d^T and Hadamard-multiply
        B = self.basis_mat
        N, D, _ = B.shape
        G = np.ones((self.N_train, self.N_train), dtype=float)
        for dd in range(self.dim):
            Bd = B[:, dd, :]             # (N, n)
            G *= Bd @ Bd.T              # accumulate Hadamard product
        return G
    
    def compute_yGy(self,   y):
        return np.einsum('N, NM,M->', y, self.G_mat , y)
    
    def compute_CG(self, iterations):
        s= self.y_train 
        q= self.y_train
        w=np.zeros(self.N_train)
        cur_r_norm_square=   self.compute_yGy( s ) 
        threshold=np.sqrt(  cur_r_norm_square)*(10**-8)
        #temp = np.sqrt(  cur_r_norm_square)
        for rr in range(iterations):
            #if rr%10==0:
                #print(rr, np.sqrt( abs(cur_r_norm_square) )/temp  )
            Gq= self.G_mat@q 
            Gq_norm=np.linalg.norm(Gq) 
            if Gq_norm<=0.0:
                break
            #print(r_norm_square)
            alpha= cur_r_norm_square /(Gq_norm **2)
            
            w= w +alpha* q
            s_new= s -alpha*Gq
            new_r_norm_square= self.compute_yGy(s_new ) 
            if new_r_norm_square<=0.0:
                break
            beta= new_r_norm_square / cur_r_norm_square
            q= s_new + beta *q
            s=s_new
            cur_r_norm_square=new_r_norm_square
            if np.sqrt( abs(new_r_norm_square))< threshold  :
                
                break
        
        return w
    
#bb=acc.T@y_train
#bb.T@bb
#y_train.T @acc@acc.T@y_train


#G_mat= CG(X_train, y_train, n , dim, N_train).G_mat
#y_train.T @acc@acc.T@y_train

CG= CG_tensor(X_train, y_train, n , dim, N_train)
y_new=CG.compute_CG(500)



###########
###########


from TT_utility import    TT_prediction

#from TT_iteration import cores_initialization, TT_svd
from nystrom import cores_initialization, TT_iterate



ranks=[2 for __ in range(dim)]
s=50
#ranks=[i+2 for i in range(dim)]

mu=0.002*dim
#mu=0.1
#from wavelet import generate_basis_mat


alpha=1/np.sqrt(dim*n)/10
#alpha=1
basis_generator =generate_basis_mat(n, dim,alpha)
basis_mat= basis_generator.all_x_multivariate(X_train)  
basis_mat = basis_mat.transpose(1, 0, 2)
x_inverse_mat=basis_generator.all_x_multivariate_inverse_alpha(X_train)


######initialization cores
cur_core_set = cores_initialization( N_train,dim,n ,ranks,s,basis_mat, y_new).all_cores()
mat_test= basis_generator.all_x_multivariate_inverse_alpha(X_test)

y_TT_full = TT_prediction().predict(dim,cur_core_set, mat_test)
print(np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true))

######end of initialization


iterations =100


for rr in range(iterations):
    
    cur_core_set= TT_iterate(N_train,n, dim ,ranks,s,basis_mat, x_inverse_mat, cur_core_set, y_train,mu).all_cores()
    if rr% 10==0:
        print('iteration=',rr)
        y_TT_full = TT_prediction().predict(dim,cur_core_set, mat_test)
        print(np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true))
        
y_TT_full= TT_prediction().predict(dim, cur_core_set, mat_test)



mse_gradient= np.linalg.norm(y_TT_full-y_true)/np.linalg.norm( y_true)
print(mse_gradient)



#####
lr= linear_model(y_train, X_train)
y_pred= lr.predict(X_test)

mse= np.linalg.norm(y_pred-y_true)/np.linalg.norm( y_true)
print('Linear',mse)




NN = NN_model (y_train, X_train, [30,30,30])
y_NN=NN.predict(X_test)
mse= np.linalg.norm(y_NN-y_true)/np.linalg.norm( y_true)
print('NN',mse)



############
"""
kernel_ridge= ridge_model(y_train, X_train)
y_kernel= kernel_ridge.predict(X_test)
mse= np.linalg.norm(y_kernel-y_true)/np.linalg.norm(y_true)
print(mse)
"""
