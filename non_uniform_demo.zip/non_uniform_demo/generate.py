import numpy as np




class generate_data:
    def __init__(self, sigma,dim):
        
        self.sigma= sigma
        self.dim= dim
        self.Q,self.a,self.b= self.make_params(self.dim)
    def function(self,X):
        
        
        return (1+ 2*np.linalg.norm(X, axis=1)/np.sqrt(self.dim))**3
        ###n=5, r=3
        #error =0.0010
        #return np.linalg.norm(X,axis=1)**2
        ###n=5, r=2
        #error= 0.00012
        #return self.f_quadratic(X)
        ###n=5, r=4
        #error 0.0035
        #return np.sum(np.sin( 2*np.pi*X),axis=1)
        ###n=6, r=2
        #error =0.00060
        
        
        
        #return np.sin( np.sum(X, axis=1))
    def generate_truncated_x(self,N, mu,var   ):
        cov= np.diag( [var for __ in range(self.dim)] )
        mean= np.array([mu for __ in range(self.dim)])
        w, Q = np.linalg.eigh(cov)             # cov = Q diag(w) Qᵀ
        w_clipped = np.clip(w, a_min=0.0, a_max=None)
        L = Q @ (np.sqrt(w_clipped)[:, None] * np.eye(self.dim)) 
        Z = np.random.randn(  N , self.dim )       # N(0, I)
        X = Z @ L.T + mean
        
        mask = np.all((X >= 0.0) & (X <= 1.0), axis=1)
        X=X[mask]
        #print(X.shape)
         
        return X
    def generate_X(self,N):
        #return  np.random.rand( N, self.dim)
        X1=self.generate_truncated_x(N*self.dim, 0.4, 0.02)[:N,:]
        X2=self.generate_truncated_x(N*self.dim, 0.7, 0.02)[:N,:]
        mask = np.random.random(N) < 0.5
        X  = np.where(mask[:, None], X1,X2)
        return X
    def generate_training(self, N ):
        
        
        X=self.generate_X(N)
        epsilon = self.sigma*np.random.randn(N)
        y =  self.function(X) + epsilon
         
        return y, X
    
    def generate_test(self, N):
        X=self.generate_X(N)
        
        y_true=  self.function(X)
        return y_true, X


    def make_params(self,d, decay_rate=2.0, L_a=1.0, seed=None):
        rng = np.random.default_rng(seed)
    
        # Q ~ N(0,1), symmetrize, then scale so ||Q||_2 <= L_Q
        dists = np.abs(np.subtract.outer(np.arange(self.dim), np.arange(self.dim)))
        Q = decay_rate ** (-dists)
    
        # a ~ N(0,1), then scale so ||a||_2 <= L_a
        a = rng.standard_normal(d)
        anorm = np.linalg.norm(a)
        if anorm > 0:
            a *= (L_a / anorm)
    
        # optional constant term
        b = rng.standard_normal()
        #Q=np.zeros(shape=(self.dim, self.dim))
        return Q, a, b

    def f_quadratic(self, X ):
        # f(x) = 0.5 x^T Q x + a^T x + b, applied row-wise to X (N,d)
        
        QX = X @ self.Q
        return 0.5 * np.einsum('ni,ni->n', X, QX) + X @ self.a + self.b

""" 
N_train=50 
dim=10
sigma=0.1
N_test=10000



generator=generate_data(sigma, dim)
y_train, X_train = generator.generate_training(N_train)

X= generator.generate_x(1000)
N=100
dim=10
cov= np.diag( [0.1 for __ in range(dim)] )
mean= np.array([0.5 for __ in range(dim)])
w, Q = np.linalg.eigh(cov)             # cov = Q diag(w) Qᵀ
w_clipped = np.clip(w, a_min=0.0, a_max=None)
L = Q @ (np.sqrt(w_clipped)[:, None] * np.eye(dim)) 
Z = np.random.randn(  N*dim, dim )       # N(0, I)
X = Z @ L.T + mean

mask = np.all((X >= 0.0) & (X <= 1.0), axis=1)
X=X[mask]
X=X[:N,]
"""
"""
import matplotlib.pyplot as plt

plt.figure() 
plt.hist(y_true, bins=30, edgecolor='black')  # try 30 bins (adjust as desired)
plt.xlabel('y value')
plt.ylabel('Frequency')
plt.title('Histogram of y')
plt.tight_layout()
plt.show()

"""