


from competitors import linear_model, NN_model,ridge_model
import numpy as np
from generate import generate_data

N_train=2000
dim=5
sigma=0.0001
N_test=10000



generator=generate_data(sigma, dim)
y_train, X_train = generator.generate_training(N_train)

y_true, X_test = generator.generate_test(N_test)




n=4
ranks=[2 for __ in range(dim)]







#####################
#####################
##################### exp cost
from polynomial_optimized import generate_basis_mat

basis_mat =generate_basis_mat(n, dim,1).all_x_multivariate(X_train)  



acc = basis_mat[:, 0, :]                  # shape (N, n)
for k in range(1, dim):
    # acc is (N, n**k), basis_mat[:,k,:] is (N, n)
    # broadcast multiply to get shape (N, n**k, n),
    # then flatten to (N, n**(k+1))
    acc = (acc[:, :, None] * basis_mat[:, k, None, :]).reshape( N_train, -1)

#acc is  ( N, n^d)  
b=np.einsum('N, Np->p',y_train, acc)
AA=acc.T@acc
np.linalg.norm(AA/N_train -np.diag([1 for __ in range(n**dim)]))

#eigenvalues, eigenvectors = np.linalg.eig(AA)

xx=np.linalg.lstsq(AA, b, rcond=None)[0]
np.linalg.norm(AA@xx-b)
full_tensor= xx.reshape(tuple([n for __ in range(dim)]))


from TT_utility import full_tensor_TT, TT_prediction
alpha=1/np.sqrt(dim*n)/10


soft_weight=np.array([alpha for __ in range(n)])
soft_weight[0]=1
for dd in range(dim):
    idx = (None,)*dd + (slice(None),) + (None,)*(dim - dd - 1)
    full_tensor= full_tensor*soft_weight[idx]
    

full_core_set= full_tensor_TT().compute_svd( dim, n, ranks, full_tensor)


basis_generator =generate_basis_mat(n, dim,alpha)

x_inverse_mat=basis_generator.all_x_multivariate_inverse_alpha(X_train)


######initialization cores
mat_test= basis_generator.all_x_multivariate_inverse_alpha(X_test)

y_TT_full = TT_prediction().predict(dim,full_core_set, mat_test)
print(np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true))

############################ 
############################ 
############################ 
############################ cg
from cg import solve_cg
alpha=1/np.sqrt(dim*n)/10

aa = solve_cg(X_train, y_train,n, dim, N_train,alpha).compute()
#bb= solve_cg(X_train, y_train,n, dim, N_train,1).lstsq()

#np.linalg.norm(aa-bb)
from polynomial_optimized import generate_basis_mat

from TT_utility import  TT_prediction

from nystrom_non_uniform import cores_initialization, TT_iterate



ranks=[2 for __ in range(dim)]
s=100





basis_generator =generate_basis_mat(n, dim,alpha)
basis_mat= basis_generator.all_x_multivariate(X_train)  
basis_mat = basis_mat.transpose(1, 0, 2)


######initialization cores
cg_core_set = cores_initialization( N_train,dim,n ,ranks,s,basis_mat, aa).all_cores()
mat_test= generate_basis_mat(n, dim, alpha**-1).all_x_multivariate_inverse_alpha(X_test)

y_TT_full = TT_prediction().predict(dim,cg_core_set, mat_test)
print(np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true)) 

########iterate


iterations =100

basis_mat_2 =generate_basis_mat(n, dim,alpha).all_x_multivariate(X_train)  
mu=2/np.sqrt(dim)

for rr in range(iterations):
    
    cg_core_set= TT_iterate(N_train,n, dim ,ranks,s,basis_mat, basis_mat_2, cg_core_set, y_train,mu).all_cores()
    if rr% 10==0:
        print('iteration=',rr)

        
        y_TT_full= TT_prediction().predict(dim, cg_core_set, mat_test)



        mse_gradient= np.linalg.norm(y_TT_full-y_true)/np.linalg.norm( y_true)
        print(mse_gradient)



 

###########
###########


from TT_utility import    TT_prediction

#from TT_iteration import cores_initialization, TT_svd
from nystrom import cores_initialization, TT_iterate

n=3

ranks=[2 for __ in range(dim)]
s=50
#ranks=[i+2 for i in range(dim)]

mu=0.002*dim
#mu=0.1
#from wavelet import generate_basis_mat


alpha=1/np.sqrt(dim*n)/10
#alpha=1
basis_generator =generate_basis_mat(n, dim,alpha)
basis_mat= basis_generator.all_x_multivariate(X_train)  
basis_mat = basis_mat.transpose(1, 0, 2)
x_inverse_mat=basis_generator.all_x_multivariate_inverse_alpha(X_train)


######initialization cores
cur_core_set = cores_initialization( N_train,dim,n ,ranks,s,basis_mat, y_train).all_cores()
mat_test= basis_generator.all_x_multivariate_inverse_alpha(X_test)

y_TT_full = TT_prediction().predict(dim,cur_core_set, mat_test)
print(np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true))

######end of initialization


iterations =100


for rr in range(iterations):
    
    cur_core_set= TT_iterate(N_train,n, dim ,ranks,s,basis_mat, x_inverse_mat, cur_core_set, y_train,mu).all_cores()
    if rr% 10==0:
        print('iteration=',rr)

        
y_TT_full= TT_prediction().predict(dim, cur_core_set, mat_test)



mse_gradient= np.linalg.norm(y_TT_full-y_true)/np.linalg.norm( y_true)
print(mse_gradient)



#####
lr = linear_model(y_train, X_train)
y_pred = lr.predict(X_test)

mse= np.linalg.norm(y_pred-y_true)/np.linalg.norm( y_true)
print('Linear',mse)




NN = NN_model (y_train, X_train, [30,30,30])
y_NN=NN.predict(X_test)
mse= np.linalg.norm(y_NN-y_true)/np.linalg.norm( y_true)
print('NN',mse)



############
"""
kernel_ridge= ridge_model(y_train, X_train)
y_kernel= kernel_ridge.predict(X_test)
mse= np.linalg.norm(y_kernel-y_true)/np.linalg.norm(y_true)
print(mse)
"""
