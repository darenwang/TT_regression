import numpy as np


class TT_exp:
    def __init__(self,N_train, dim, n):
        self.N=N_train
        self.dim=dim
        self.n=n

    
    def compute_full_tensor(self, basis_mat,y):
        
        acc = basis_mat[:, 0, :]                  # shape (N, n)
        for k in range(1, self.dim):
            # acc is (N, n**k), basis_mat[:,k,:] is (N, n)
            # broadcast multiply to get shape (N, n**k, n),
            # then flatten to (N, n**(k+1))
            acc = (acc[:, :, None] * basis_mat[:, k, None, :]).reshape(self.N, -1)
        
        # 2) Weight each row by y_train and sum over samples
        #    acc.T @ y_train gives a vector of length n**d
        flat = acc.T @ y                 # shape (n**d,)
        
        # 3) Reshape back into your full_mat of shape (n, n, …, n) (d times)
        full_mat = flat.reshape((self.n,) * self.dim)
        return full_mat/self.N