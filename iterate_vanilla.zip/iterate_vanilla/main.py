


from competitors import linear_model, NN_model,ridge_model
import numpy as np
from generate import generate_data

N_train=5000
dim=5
sigma=0.00001
N_test=10000



generator=generate_data(sigma, dim)
y_train, X_train = generator.generate_training(N_train)

y_true, X_test = generator.generate_test(N_test)



####### soft initialization + soft iterate 


from polynomial_optimized import generate_basis_mat
from TT_utility import    TT_prediction
from TT_iteration import cores_initialization, TT_iterate

#

n=3

ranks=[2 for __ in range(dim)]


mu=0.5/ dim 


alpha=1/np.sqrt(dim*n)/10
#alpha=1
basis_generator =generate_basis_mat(n, dim,alpha)
basis_mat= basis_generator.all_x_multivariate(X_train)  
basis_mat = basis_mat.transpose(1, 0, 2)
x_inverse_mat=basis_generator.all_x_multivariate_inverse_alpha(X_train)


######O(N^2) vanilla  initialization cores
cur_core_set = cores_initialization( N_train,dim,n ,ranks ,basis_mat, y_train).all_cores()

mat_test= basis_generator.all_x_multivariate_inverse_alpha(X_test)

y_TT_full = TT_prediction().predict(dim,cur_core_set, mat_test)
print(np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true))

######end of initialization

mu=0.25/ dim 

iterations =200


for rr in range(iterations):
    
    cur_core_set= TT_iterate(N_train,n, dim ,ranks ,basis_mat, x_inverse_mat, cur_core_set, y_train,mu).all_cores()
    if rr% 10==0:
        print('iteration=',rr)

        
        y_TT_full= TT_prediction().predict(dim, cur_core_set, mat_test)



        mse_gradient= np.linalg.norm(y_TT_full-y_true)/np.linalg.norm( y_true)
        print(mse_gradient)




####### Nystrom: soft initialization + soft iterate 

from nystrom import cores_initialization, TT_iterate
 

#

n=3

ranks=[2 for __ in range(dim)]


mu=0.25/ np.sqrt(dim) 


alpha=1/np.sqrt(dim*n)/10
#alpha=1
basis_generator =generate_basis_mat(n, dim,alpha)
basis_mat= basis_generator.all_x_multivariate(X_train)  
basis_mat = basis_mat.transpose(1, 0, 2)
x_inverse_mat=basis_generator.all_x_multivariate_inverse_alpha(X_train)
s=100
cur_core_set = cores_initialization( N_train,dim,n ,ranks,s,basis_mat, y_train).all_cores()

mat_test= basis_generator.all_x_multivariate_inverse_alpha(X_test)

y_TT_full = TT_prediction().predict(dim,cur_core_set, mat_test)
print(np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true))

######end of initialization


iterations =400


for rr in range(iterations):
    
    cur_core_set= TT_iterate(N_train,n, dim ,ranks,s,basis_mat, x_inverse_mat, cur_core_set, y_train,mu).all_cores()
    if rr% 10==0:
        print('iteration=',rr)

        
        y_TT_full= TT_prediction().predict(dim, cur_core_set, mat_test)



        mse_gradient= np.linalg.norm(y_TT_full-y_true)/np.linalg.norm( y_true)
        print(mse_gradient)

nystrom_cores=cur_core_set 


####################   iterate vanilla
####################
####################


from TT_iteration import cores_initialization 



n=3 

ranks=[2 for __ in range(dim)]





alpha=1/np.sqrt(dim*n)/10

#alpha=1
basis_generator =generate_basis_mat(n, dim,alpha)
basis_mat= basis_generator.all_x_multivariate(X_train)  
basis_mat = basis_mat.transpose(1, 0, 2)


######O(N^2) vanilla  initialization cores
cur_core_set = cores_initialization( N_train,dim,n ,ranks ,basis_mat, y_train).all_cores()

def unweight(alpha_inverse, core_set):
    inverse_vec=np.ones(n)*alpha_inverse
    inverse_vec[0]=1
    core_set[0]= np.einsum('Nr, N->Nr', core_set[0], inverse_vec)
    for dd in range(1, dim-1):
        core_set[dd]=np.einsum('sNr, N->sNr',  core_set[dd], inverse_vec)

    core_set[-1]= np.einsum('rN, N->rN',  core_set[-1], inverse_vec)


mat_test= generate_basis_mat(n, dim,1).all_x_multivariate_inverse_alpha(X_test)

y_TT_full = TT_prediction().predict(dim,cur_core_set, mat_test)
print(np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true))



###########iteratations

record_tuning= [] 
converge_table =  []

from TT_iteration import   TT_iterate
 
for ii in range(1,10):
    record_tuning.append([])
    converge_table.append([])
    for jj in range(1,10):

        
        cur_core_set =[np.copy(nystrom_cores[kk]) for kk in range(dim)]

        unweight(alpha**-1, cur_core_set)
        sigma_core=(10**-5)/ii 
        #####add noise to nystrom_cores
        for k in range(len(cur_core_set)):
            cur_shape=cur_core_set[k].shape
            cur_core_set[k] +=np.random.normal(0, sigma_core, cur_shape) 
            
        
        
        
        
        
        
        
        
        mat_test= generate_basis_mat(n, dim,1).all_x_multivariate_inverse_alpha(X_test)
        
        y_TT_full = TT_prediction().predict(dim,cur_core_set, mat_test)
        error= np.linalg.norm(y_TT_full -y_true)/np.linalg.norm( y_true)
        #print(error)
        
        
        
        
        iterations =50
        mu=0.01/jj
        record_tuning[-1].append([error.item(), mu])
        
        
        
        basis_mat_2= generate_basis_mat(n, dim,1).all_x_multivariate(X_train)  
        basis_mat = basis_mat_2.transpose(1, 0, 2)
        
        converge_table[-1].append(True)
        for rr in range(iterations):
            
            cur_core_set= TT_iterate(N_train,n, dim ,ranks ,basis_mat, basis_mat_2, cur_core_set, y_train,mu).all_cores()
            y_TT_full= TT_prediction().predict(dim, cur_core_set, mat_test)
    
            
    
            mse_gradient= np.linalg.norm(y_TT_full-y_true)/np.linalg.norm( y_true)
            if mse_gradient>50*error:
                converge_table[-1][-1] = False
                break

            
            #if rr% 10==0:
                #print('iteration=',rr)
                #print(mse_gradient)
        record_tuning[-1][-1].append(mse_gradient.item())
        
        if record_tuning[-1][0]< record_tuning[-1][-1]:
            converge_table[-1][-1] = False
        print( record_tuning[-1][-1],converge_table[-1][-1] )
converge_table
record_tuning

[[False, False, False, False, False, False, False, False, False],
 [False, False, False, False, False, False, False, True, False],
 [False, False, False, False, False, False, False, True, False],
 [False, False, False, False, False, False, False, False, False],
 [False, False, False, False, False, False, False, False, False],
 [False, False, False, False, True, False, False, False, False],
 [False, False, False, False, False, True, False, False, True],
 [False, False, False, True, True, True, True, True, True],
 [False, False, False, False, True, True, True, True, True]]


[[False, False, False, False, False, False, False, False, False],
 [False, False, False, False, False, False, False, True, False],
 [False, False, False, False, False, False, False, True, False],
 [False, False, False, False, False, False, False, True, True],
 [False, False, False, False, False, False, True, True, True],
 [False, False, False, False, False, False, False, True, True],
 [False, False, False, True, True, True, True, True, True],
 [False, False, False, False, False, False, True, False, False],
 [False, False, False, False, False, True, True, True, True]]

np.save('record_tuning.npy', record_tuning)
record_tuning_2=np.load('record_tuning.npy')
####################   competitors
####################
####################
lr= linear_model(y_train, X_train)
y_pred= lr.predict(X_test)

mse= np.linalg.norm(y_pred-y_true)/np.linalg.norm( y_true)
print('Linear',mse)




NN = NN_model (y_train, X_train, [30,30,30])
y_NN=NN.predict(X_test)
mse= np.linalg.norm(y_NN-y_true)/np.linalg.norm( y_true)
print('NN',mse)



############
"""
kernel_ridge= ridge_model(y_train, X_train)
y_kernel= kernel_ridge.predict(X_test)
mse= np.linalg.norm(y_kernel-y_true)/np.linalg.norm(y_true)
print(mse)
"""
