


from generate import generate_sin, generate_linear
from model import linear_model, NN_model,ridge_model
import numpy as np
from generate import generate_linear, generate_sin

N_train=5000
dim=4
sigma=2
N_test=10000



generator=generate_sin(sigma, dim)
y_train, X_train = generator.generate_training(N_train)

y_true, X_test = generator.generate_test(N_test)



#####
lr= linear_model(y_train, X_train)
y_pred= lr.predict(X_test)

mse= np.linalg.norm(y_pred-y_true)/N_train
print(mse)




NN = NN_model (y_train, X_train, [10,10,10])
y_NN=NN.predict(X_test)
mse= np.linalg.norm(y_NN-y_true)/N_train
print(mse)



############

kernel_ridge= ridge_model(y_train, X_train)
y_kernel= kernel_ridge.predict(X_test)
mse= np.linalg.norm(y_kernel-y_true)/np.linalg.norm(y_true)
print(mse)



########## n^dim cost tensor 


from polynomial_optimized import generate_basis_mat
from TT_ultility import full_tensor_TT,  TT_prediction
from TT_exp import TT_exp
n=3
ranks=[2 for __ in range(dim)]
#from wavelet import generate_basis_mat
mu=0.01

alpha=1/np.sqrt(dim*n) 
#alpha=1
basis_generator =generate_basis_mat(n, dim,alpha)
basis_mat= basis_generator.all_x_multivariate(X_train)  
inverse_mat=basis_generator.all_x_multivariate_inverse_alpha(X_train)




TT_exp_model= TT_exp(N_train, dim, n)
cur_tensor_no_structure=TT_exp_model.compute_full_tensor(basis_mat, y_train)



""" 
###############debug
core_set_cur = full_tensor_TT().compute(dim,n,ranks,cur_tensor_no_structure)
core_set_full_ini= core_set_cur[:]
cur_tensor_no_structure=full_tensor_TT().full_TT(core_set_cur) 

tensor_train_cur = full_tensor_TT().full_TT(core_set_cur) 
#####compute the prediction on X_train
y_t =  TT_prediction().predict(dim, core_set_cur, inverse_mat)

#compute the second term of gradient
gradient_term_2 = TT_exp_model.compute_full_tensor(basis_mat, y_t)
#the first term of of gradient is the start_tensor
cur_tensor_no_structure = tensor_train_cur + mu * (start_tensor - gradient_term_2 )
core_set_cur = full_tensor_TT().compute(dim,n,ranks,cur_tensor_no_structure)
#B=cur_tensor_no_structure.reshape(n,-1)
#AA=B @ B.T

#######################
"""

#####gradient descent 
iterations = 201


for rr in range(iterations):
    if rr% 50==0:
        print('iteration=',rr)
    ##compute cores
    core_set_cur = full_tensor_TT().compute(dim,n,ranks,cur_tensor_no_structure)
    ##compute tensor_train based on cores
    tensor_train_cur = full_tensor_TT().full_TT(core_set_cur) 
    #####compute the prediction on X_train
    y_t =  TT_prediction().predict(dim, core_set_cur, inverse_mat)
    
    #compute the second term of gradient
    gradient_term  = TT_exp_model.compute_full_tensor(basis_mat,y_train- y_t)
    #the first term of of gradient is the start_tensor
    cur_tensor_no_structure = tensor_train_cur + mu *   gradient_term 
    


#####
#####tensor_train_cur is a collection of cores
##### gradient= (start_tensor - gradient_term_2 )  can be stored as 
##### (y_train-y_t).shape(N), and basis_mat.shape (N, dim, n), where they form
##### (y_train-y_t)[i] *Phi[i], where Phi[i] is the rank one tensor phi_1\otimes\cdots \phi_d
##### we need to compute TT decomposition of ( tensor_train_cur + gradient)
##### We apply the quadratic implementation
##### A_k= ( tensor_train_cur + gradient).shape (rn, n^{k})
##### then compute A_k A_k^\top 
##### Let's try first code, second to dim-1 cores, and last core stratergy
###############################################
###############################################
################  first cores  ################ 
##### for the first core, we have three terms 
##### tensor_train_cur *tensor_train_cur^top
##### gradient *gradient ^\top  (there is a version in density)
##### 2* tensor_train_cur * gradient ^\top

###### Then consider updates


##################











mat_test= basis_generator.all_x_multivariate_inverse_alpha(X_test)
y_TT_full= TT_prediction().predict(dim, core_set_cur, mat_test)



mse_gradient= np.linalg.norm(y_TT_full-y_true)/N_train
print(mse_gradient)

#0.18004224834817653-0.18004224834817797
#0.037745210553552525-0.03774521055354955
